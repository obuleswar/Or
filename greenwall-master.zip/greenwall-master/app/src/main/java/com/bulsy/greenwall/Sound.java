package com.bulsy.greenwall;

/**
 * Created by ugliest on 2/28/15.
 */
public enum Sound {
    COMBO, THROW, SPLAT, WETSPLAT, KSPLAT, PASSLEVEL, DEATH
}
