# greenwall
a weirdly addictive arcade-style android game, where you fling fruit at a wall.

this is a first foray into android programming.  nothing crazy, no test cases.  just
a whole lot of state manipulation and tightly coupled everything (so, more or less the 
opposite of what you'd want in a versatile/maintainable business app).

play is self explanatory -- just splatting various food items 
by throwing them at the wall.  typical cartoonish arcade game feel, play gets
faster and more difficult gradually each round.

playable executable available at
https://play.google.com/store/apps/details?id=com.bulsy.greenwall

have fun :)
